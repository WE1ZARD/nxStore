NX-Cast install
===============

Recommended install:
1. Extract this zip to the root of your Switch SD card.
2. Confirm the final path is:
   sdmc:/switch/NX-Cast/NX-Cast.nro
3. Launch NX-Cast from hbmenu.

Do not extract this zip into an extra nested folder such as:
sdmc:/NX-Cast-sdmc/switch/NX-Cast/

Included files:
- switch/NX-Cast/NX-Cast.nro
- switch/NX-Cast/dlna/ runtime DLNA description assets
- switch/NX-Cast/fonts/ packaged UI font and license notices
- switch/NX-Cast/iptv/sources.txt preinstalled IPTV sources
- switch/NX-Cast/iptv/ local playlists, remote source/cache location, and usage notes
- switch/NX-Cast/airplay/ AirPlay storage notice; identity and pairings are generated on first launch
- switch/NX-Cast/licenses/ third-party license notices

If NX-Cast does not appear in hbmenu, check the SD card path above.
If the UI font looks wrong, reinstall this full SD package instead of copying
only the NRO.

Switch Frame Tap 0.7.21.1 - the viewer for macOS (arm64, macOS 12.0 or newer)

Drag "Switch Frame Tap.app" to Applications. It is not signed by Apple: the
first time, right-click it and choose Open (or run
  xattr -dr com.apple.quarantine "/Applications/Switch Frame Tap.app"
in Terminal). No driver is needed for USB on macOS.

FFmpeg (H.264, AAC, MP4), SDL 2 and libusb are built in.
https://github.com/TomasUribe/switch-frame-tap

## 介绍
Master Volume是[`averne`](https://github.com/averne/MasterVolume)的开源工具之一,
支持底座投屏时使用手柄控制音量, 
我在他的基础上修改了功能逻辑, 更符合使用习惯.


## 使用说明
- 下载解压包之后, 将`switch`文件夹覆盖到`SD卡`根目录
- 按快捷键(`L`+`✚`)呼出菜单管理界面, 选择并打开`MasterVolume`
- `Volume`旁边的数字是音量的大小, `最多可以8倍`, 退出重新打开的时候自动重置为1
- `Force Speaker Output`点击之后允许底座投屏时的声音从switch喇叭输出, 给投屏但是显示器不支持输出声音的用户使用.